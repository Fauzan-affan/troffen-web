exports.id = 823;
exports.ids = [823];
exports.modules = {

/***/ 1291:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "MonthlyPass_container__5U4qF",
	"content_container": "MonthlyPass_content_container__329Hm",
	"content": "MonthlyPass_content__nxrnF",
	"title": "MonthlyPass_title__vovtJ",
	"title_1": "MonthlyPass_title_1__SxyW1",
	"title_2": "MonthlyPass_title_2__CgGYt",
	"content_left": "MonthlyPass_content_left__1fux2",
	"content_left_card": "MonthlyPass_content_left_card__IJL1z",
	"card_header": "MonthlyPass_card_header__pRgOP",
	"card_header_img": "MonthlyPass_card_header_img__4nj40",
	"card_header_price": "MonthlyPass_card_header_price__dMtEK",
	"card_header_price_label": "MonthlyPass_card_header_price_label__cxWQ3",
	"card_header_price_amount": "MonthlyPass_card_header_price_amount__dToHB",
	"card_content_1": "MonthlyPass_card_content_1__MImvN",
	"card_content_2": "MonthlyPass_card_content_2__9X52A",
	"card_content_3": "MonthlyPass_card_content_3__Orx8W",
	"img_info_container": "MonthlyPass_img_info_container__Sqf0u",
	"e1": "MonthlyPass_e1__IBDDo",
	"e2": "MonthlyPass_e2__oksG8",
	"content_left_info": "MonthlyPass_content_left_info__U3C9U",
	"vertical_hr": "MonthlyPass_vertical_hr__wpTzd",
	"content_right": "MonthlyPass_content_right___KQe1",
	"option_1_header": "MonthlyPass_option_1_header__5cW6D",
	"option_2_header": "MonthlyPass_option_2_header__JTEt_",
	"option_1_header_top": "MonthlyPass_option_1_header_top__Em5uD",
	"option_2_header_top": "MonthlyPass_option_2_header_top__e2pi1",
	"option_1_header_left": "MonthlyPass_option_1_header_left__KnKr7",
	"option_2_header_left": "MonthlyPass_option_2_header_left__IuCtb",
	"img_container_1": "MonthlyPass_img_container_1__BD6Pe",
	"img_container_2": "MonthlyPass_img_container_2__jVvwT",
	"option_1_header_right": "MonthlyPass_option_1_header_right__RNIMH",
	"option_2_header_right": "MonthlyPass_option_2_header_right__B_o3A",
	"option_1": "MonthlyPass_option_1__swqWe",
	"QR": "MonthlyPass_QR__V6Q23",
	"option_1_body": "MonthlyPass_option_1_body__i9AJU"
};


/***/ }),

/***/ 9823:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ core_Tab)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./styles/MonthlyPass.module.css
var MonthlyPass_module = __webpack_require__(1291);
var MonthlyPass_module_default = /*#__PURE__*/__webpack_require__.n(MonthlyPass_module);
;// CONCATENATED MODULE: ./assets/img/strip.svg
/* harmony default export */ const strip = ({"src":"/_next/static/media/strip.d461d95e.svg","height":2,"width":18});
;// CONCATENATED MODULE: ./assets/img/plus.svg
/* harmony default export */ const plus = ({"src":"/_next/static/media/plus.098cb24f.svg","height":14,"width":14});
;// CONCATENATED MODULE: ./assets/img/png/qr.png
/* harmony default export */ const qr = ({"src":"/_next/static/media/qr.75e361a7.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAdElEQVR42g3HPwsBcQCA4eczyaIug8lgYTJZECcsh8ufyaaUpCTpTAYZiVH5BPeR/HqHt4fcy0msYO8tFziSmWl66Ac5hyZ2BhruLnQMbXWtFS3DrVTUpKoSUz8yBwttc3WRFk9jV6meWOJI7mOj5KvsJvoDsF4fznZYGs4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/core/Tab.js







const masukSebagaiLabel = {
    fontWeight: 400
};
const masukSebagaiHr = {
    border: "1px solid"
};
const masukSebagaiSelectedLabel = {
    fontWeight: 600,
    fontSize: "16px"
};
const masukSebagaiSelectedHr = {
    border: "2px solid"
};
const Tab = ({ tabObj , defaultType ="" , isHeader  })=>{
    const [paymentType, setPaymentType] = (0,external_react_.useState)(defaultType);
    const [toogleBCA, setToogleBCA] = (0,external_react_.useState)(true);
    const [tooglePermata, setTooglePermata] = (0,external_react_.useState)(false);
    const [toogleFAQ1, setToogleFAQ1] = (0,external_react_.useState)(true);
    const [toogleFAQ2, setToogleFAQ2] = (0,external_react_.useState)(false);
    const [toogleFAQ3, setToogleFAQ3] = (0,external_react_.useState)(false);
    const changePaymentType = (type)=>{
        setPaymentType(type);
    };
    const handleToogle = (val)=>{
        val === "BCA" && setToogleBCA(!toogleBCA);
        val === "Bank Permata" && setTooglePermata(!tooglePermata);
        // FAQ
        val === "Apa itu Troffen?" && setToogleFAQ1(!toogleFAQ1);
        val === "Bagaimana Cara Menjadi Guru di Troffen?" && setToogleFAQ2(!toogleFAQ2);
        val === "Bagaimana Cara Memesan Kursus di Troffen?" && setToogleFAQ3(!toogleFAQ3);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            isHeader && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "masuk_modal_type",
                children: tabObj.map((obj, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "masuk_sebagai_murid",
                        onClick: ()=>changePaymentType(obj.id),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                style: paymentType === obj.id ? masukSebagaiSelectedLabel : masukSebagaiLabel,
                                children: obj.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                style: paymentType === obj.id ? masukSebagaiSelectedHr : masukSebagaiHr
                            })
                        ]
                    }, obj.id))
            }),
            paymentType === tabObj[0].id && tabObj.map((obj, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (MonthlyPass_module_default()).payment_container,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (MonthlyPass_module_default()).option_1,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_header,
                                onClick: ()=>handleToogle(obj.optionName),
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (MonthlyPass_module_default()).option_1_header_top,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (MonthlyPass_module_default()).option_1_header_left,
                                            children: [
                                                obj.optionImg && /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                    className: (MonthlyPass_module_default()).img_container_1,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        alt: "",
                                                        src: obj.optionImg,
                                                        priority: true,
                                                        width: 100,
                                                        height: 100
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                    children: obj.optionName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (MonthlyPass_module_default()).option_1_header_right,
                                            children: obj.optionName === "BCA" && toogleBCA || obj.optionName === "Bank Permata" && tooglePermata || obj.optionName === "Apa itu Troffen?" && toogleFAQ1 || obj.optionName === "Bagaimana Cara Menjadi Guru di Troffen?" && toogleFAQ2 || obj.optionName === "Bagaimana Cara Memesan Kursus di Troffen?" && toogleFAQ3 ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: strip,
                                                priority: true
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: plus,
                                                priority: true
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                            obj.optionName === "BCA" && toogleBCA && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_body,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                                    children: obj.desc.map((desc)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: desc.val
                                        }, desc.descId))
                                })
                            }),
                            obj.optionName === "Bank Permata" && tooglePermata && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_body,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                                    children: obj.desc.map((desc)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: desc.val
                                        }, desc.descId))
                                })
                            }),
                            obj.optionName === "Apa itu Troffen?" && toogleFAQ1 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_body,
                                children: obj.desc.map((desc)=>/*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: desc.val
                                    }, desc.id))
                            }),
                            obj.optionName === "Bagaimana Cara Menjadi Guru di Troffen?" && toogleFAQ2 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_body,
                                children: obj.desc.map((desc)=>/*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: desc.val
                                    }, desc.id))
                            }),
                            obj.optionName === "Bagaimana Cara Memesan Kursus di Troffen?" && toogleFAQ3 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MonthlyPass_module_default()).option_1_body,
                                children: obj.desc.map((desc)=>/*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: desc.val
                                    }, desc.id))
                            })
                        ]
                    })
                }, obj.id)),
            paymentType === tabObj[1].id && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (MonthlyPass_module_default()).payment_container,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (MonthlyPass_module_default()).QR,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "",
                            src: qr,
                            priority: true,
                            width: 300,
                            height: 300
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                            children: "Transfer melalui QRIS a/n Troffen."
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const core_Tab = (Tab);


/***/ })

};
;