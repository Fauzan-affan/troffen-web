exports.id = 54;
exports.ids = [54];
exports.modules = {

/***/ 3651:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Jumbotron_container__PYUva",
	"search_bar": "Jumbotron_search_bar__VcaTR",
	"search_title": "Jumbotron_search_title__FA3nr",
	"search_desc": "Jumbotron_search_desc__nwyi0",
	"search_box": "Jumbotron_search_box__fzK0l",
	"search_subject": "Jumbotron_search_subject__aq6H2",
	"search_location": "Jumbotron_search_location__OjXIf",
	"search_location_left": "Jumbotron_search_location_left__KbQVD",
	"search_location_right": "Jumbotron_search_location_right__voUYA",
	"search_location_mobile": "Jumbotron_search_location_mobile__XgSXG",
	"button_search": "Jumbotron_button_search__3kf8t",
	"button_filter": "Jumbotron_button_filter__Ec3Im"
};


/***/ }),

/***/ 975:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bg-biru.43efb569.svg","height":304,"width":1440});

/***/ }),

/***/ 9054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3651);
/* harmony import */ var _styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_img_bg_biru_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(975);



const Jumbotron = ({ title , desc , placeholder , buttonLabel  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "search_bar",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_bar),
            style: {
                backgroundImage: `url(${_assets_img_bg_biru_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"].src */ .Z.src})`
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().container),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().container_search),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_title),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: title
                            })
                        }),
                        desc && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_desc),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: desc
                            })
                        }),
                        placeholder && buttonLabel && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_box),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_location),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_location_left),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            placeholder: placeholder
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().search_location_right),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: (_styles_core_Jumbotron_module_css__WEBPACK_IMPORTED_MODULE_2___default().button_search),
                                            children: buttonLabel
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Jumbotron);


/***/ })

};
;