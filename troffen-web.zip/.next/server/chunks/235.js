exports.id = 235;
exports.ids = [235];
exports.modules = {

/***/ 584:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "Input_wrapper__8f55v",
	"input": "Input_input__pn_fc",
	"wrapper_side": "Input_wrapper_side__08zYn",
	"input_wrapper": "Input_input_wrapper__QSpmf",
	"input_main": "Input_input_main__7Dn9R",
	"input_label": "Input_input_label__p12ox",
	"input_label_text": "Input_input_label_text__OkwKl"
};


/***/ }),

/***/ 9547:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Progress_container__f6VVR",
	"wrapper": "Progress_wrapper__09Shk",
	"progress_label": "Progress_progress_label__S4E02",
	"active": "Progress_active__oYDXq"
};


/***/ }),

/***/ 7817:
/***/ ((module) => {

// Exports
module.exports = {
	"label": "Select_label__QD0gQ",
	"wrapper": "Select_wrapper__xUBX9"
};


/***/ }),

/***/ 5258:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "Upload_wrapper__uKIOm",
	"input": "Upload_input__xe8ki",
	"input_pengalaman": "Upload_input_pengalaman__PqSvL",
	"input_file": "Upload_input_file__2MTAO",
	"custom_file_input": "Upload_custom_file_input__BwVLy"
};


/***/ }),

/***/ 9004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/1.a15035fa.svg","height":24,"width":8});

/***/ }),

/***/ 7013:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/2.ceac3226.svg","height":24,"width":17});

/***/ }),

/***/ 7055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/EllipseNo.504d2521.svg","height":80,"width":80});

/***/ }),

/***/ 4846:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bg_daftar_guru.6db70c9a.svg","height":907,"width":694});

/***/ }),

/***/ 9268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(584);
/* harmony import */ var _styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Input = ({ type ="" , label , desc , name , placeholder , inputLabel ="" , handleChange  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            type === "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().wrapper),
                children: [
                    label.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        htmlFor: label,
                        children: label
                    }),
                    desc.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        children: desc
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().input),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            id: name,
                            name: name,
                            type: "text",
                            placeholder: placeholder,
                            onChange: handleChange
                        })
                    })
                ]
            }),
            type === "sideLabel" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().wrapper_side),
                children: [
                    label.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        htmlFor: label,
                        children: label
                    }),
                    desc.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                        children: desc
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_wrapper),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_main),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    id: name,
                                    name: name,
                                    type: "text",
                                    placeholder: placeholder,
                                    onChange: handleChange
                                })
                            }),
                            inputLabel.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_label),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                    className: (_styles_core_Input_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_label_text),
                                    children: inputLabel
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);


/***/ }),

/***/ 5134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ core_Progress)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/core/Progress.module.css
var Progress_module = __webpack_require__(9547);
var Progress_module_default = /*#__PURE__*/__webpack_require__.n(Progress_module);
;// CONCATENATED MODULE: ./assets/img/progress_dvdr.svg
/* harmony default export */ const progress_dvdr = ({"src":"/_next/static/media/progress_dvdr.7a85393a.svg","height":9,"width":69});
;// CONCATENATED MODULE: ./assets/img/DvdrActive.svg
/* harmony default export */ const DvdrActive = ({"src":"/_next/static/media/DvdrActive.366e7da9.svg","height":9,"width":69});
;// CONCATENATED MODULE: ./assets/img/blue_checklist.svg
/* harmony default export */ const blue_checklist = ({"src":"/_next/static/media/blue_checklist.3a255ce0.svg","height":16,"width":16});
;// CONCATENATED MODULE: ./assets/img/Ellipse.svg
/* harmony default export */ const Ellipse = ({"src":"/_next/static/media/Ellipse.33b6dced.svg","height":18,"width":18});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/core/Progress.js







const Progress = ({ stage , route  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Progress_module_default()).container,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Progress_module_default()).wrapper,
                children: [
                    stage === "Personal Info" && route === "daftar-murid" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: blue_checklist
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        className: (Progress_module_default()).active,
                                        children: "Informasi Pribadi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: progress_dvdr
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Pengalaman"
                                    })
                                ]
                            })
                        ]
                    }),
                    stage === "Experiences" && route === "daftar-murid" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: blue_checklist
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        className: (Progress_module_default()).active,
                                        children: "Informasi Pribadi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: DvdrActive
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Pengalaman"
                                    })
                                ]
                            })
                        ]
                    }),
                    stage === "Personal Info" && route === "daftar-guru" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: blue_checklist
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        className: (Progress_module_default()).active,
                                        children: "Informasi Pribadi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: progress_dvdr
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Pengalaman"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: progress_dvdr
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Subjek Kursus"
                                    })
                                ]
                            })
                        ]
                    }),
                    stage === "Experiences" && route === "daftar-guru" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: blue_checklist
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        className: (Progress_module_default()).active,
                                        children: "Informasi Pribadi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: DvdrActive
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Pengalaman"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: progress_dvdr
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Subjek Kursus"
                                    })
                                ]
                            })
                        ]
                    }),
                    stage === "Subjek Kursus" && route === "daftar-guru" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: blue_checklist
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        className: (Progress_module_default()).active,
                                        children: "Informasi Pribadi"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: DvdrActive
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Pengalaman"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: "",
                                src: DvdrActive
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Progress_module_default()).progress_label,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        alt: "",
                                        src: Ellipse
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        children: "Subjek Kursus"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const core_Progress = (Progress);


/***/ }),

/***/ 4091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ core_Select)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/core/Select.module.css
var Select_module = __webpack_require__(7817);
var Select_module_default = /*#__PURE__*/__webpack_require__.n(Select_module);
;// CONCATENATED MODULE: ./assets/img/dw.svg
/* harmony default export */ const dw = ({"src":"/_next/static/media/dw.a94d39b6.svg","height":10,"width":20});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/core/Select.js




const Select = ({ label , optionLabel , desc , name , options =[] , handleChange  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            label.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Select_module_default()).label,
                htmlFor: label,
                children: label
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Select_module_default()).wrapper,
                children: [
                    desc.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        children: desc
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        name: name,
                        id: name,
                        onChange: handleChange,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "",
                                selected: true,
                                disabled: true,
                                children: optionLabel
                            }),
                            options.map((option, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: option.value,
                                    children: option.name
                                }, i))
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        alt: "",
                        src: dw
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const core_Select = (Select);


/***/ }),

/***/ 6498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5258);
/* harmony import */ var _styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Upload = ({ stage , label , desc , name , handleChange  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default().wrapper),
            children: [
                label.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    htmlFor: label,
                    children: label
                }),
                desc.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                    children: desc
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                    className: stage === "Experiences" || stage === "Subjek Kursus" ? (_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_pengalaman) : (_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default().input),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        id: name,
                        name: name,
                        type: "file",
                        className: stage === "Experiences" || stage === "Subjek Kursus" ? (_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default().custom_file_input) : (_styles_core_Upload_module_css__WEBPACK_IMPORTED_MODULE_1___default().input_file),
                        onChange: handleChange
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Upload);


/***/ })

};
;