import { useState } from "react";

import Image from "next/image";
import LoginTemplate from "../../components/layouts/LoginTemplate";
import styles from "../../styles/DaftarMurid.module.css";

import Jumbo from "../../assets/img/pendaftaraan/bg_daftar_guru.svg";

import Email from "../../assets/img/png/001-mail.png";
import Pass from "../../assets/img/png/002-eye.png";
import Google from "../../assets/img/png/002-search.png";
import Fb from "../../assets/img/png/001-facebook.png";

const DaftarMurid = () => {
  const [state, setState] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const target = e.target;
    const value = target.value;
    const name = target.name;

    setState((state) => ({
      ...state,
      [name]: value,
    }));
  };

  const handleRegister = (e) => {
    e.preventDefault();
    console.log(state);
  };

  return (
    <LoginTemplate
      title={`Platform Belajar High Demand Skill Dengan Mudah - Troffen`}
      desc={`Bingung Cara Belajar Skill Baru? atau Kesulitan Nemuin Pengajar Berkualitas? Tinggal cari aja di Troffen, Platform Belajar Skill Baru Dengan Mudah`}
      icon={`troffen.ico`}
      isNavbar={`memberNavbar`}
    >
      <section id={styles.jumbotron}>
        <div className={styles.container}>
          <div className={styles.body}>
            <div className={styles.body_left}>
              <Image alt="" src={Jumbo} width={550} height={700} />
            </div>
            <div className={styles.body_right}>
              <div className={styles.body_right_container}>
                <div className={styles.title}>Daftar Sebagai Murid</div>
                <div className={styles.desc}>Temukan guru sesuai keahlian yang Anda inginkan. Melalui Troffen, Anda dapat mengembangkan keahlian lebih baik.</div>

                <form onSubmit={handleRegister}>
                  <div className="masuk_modal_body">
                    <div className="masuk_email">
                      <label htmlFor="email">Email*</label>
                      <nav>
                        <input id="email" name="email" type="text" placeholder="example@gmail.com" value={state.email} onChange={handleChange} />
                        <Image alt="" src={Email} priority width={20} height={20} />
                      </nav>
                    </div>
                    <div className="masuk_password">
                      <label htmlFor="password">Password*</label>
                      <nav>
                        <input id="password" name="password" type="password" placeholder="password" value={state.password} onChange={handleChange} />
                        <Image alt="" src={Pass} priority width={20} height={20} />
                      </nav>
                    </div>
                    <button type="submit" className="masuk_submit">
                      Daftar
                    </button>
                    <div className="masuk_options">
                      <div className="masuk_option_label">atau masuk dengan</div>
                      <div className="masuk_options_body">
                        <div className="masuk_google">
                          <Image alt="" src={Google} priority width={20} height={20} />
                          <nav>Google</nav>
                        </div>
                        <div className="masuk_facebook">
                          <Image alt="" src={Fb} priority width={20} height={20} />
                          <nav>Facebook</nav>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </LoginTemplate>
  );
};

export default DaftarMurid;
