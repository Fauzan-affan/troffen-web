const DaftarGuru = () => {
  return <div>DaftarGuru</div>;
};

export default DaftarGuru;
