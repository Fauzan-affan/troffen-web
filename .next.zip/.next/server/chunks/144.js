exports.id = 144;
exports.ids = [144];
exports.modules = {

/***/ 5414:
/***/ ((module) => {

// Exports
module.exports = {
	"modal_overlay": "Modal_modal_overlay__emV_k",
	"modal_daftar": "Modal_modal_daftar__mAPCy",
	"modal_masuk": "Modal_modal_masuk__pXUE1",
	"modal_footer_daftar": "Modal_modal_footer_daftar__xprP0",
	"modal_footer_masuk": "Modal_modal_footer_masuk__THT6c",
	"modal_close": "Modal_modal_close__Zto0H",
	"modal_body": "Modal_modal_body__UTUmb",
	"modal_title": "Modal_modal_title__NMfDt"
};


/***/ }),

/***/ 1846:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Footer_container__gxTJe",
	"footer": "Footer_footer__XmMdF",
	"footer_menu": "Footer_footer_menu__er8zl",
	"footer_copyright": "Footer_footer_copyright__atI1F",
	"footer_alamat_logo": "Footer_footer_alamat_logo__ZX2sw",
	"footer_alamat_logo_1": "Footer_footer_alamat_logo_1__HbPqa",
	"footer_alamat_logo_2": "Footer_footer_alamat_logo_2__F8Eme",
	"footer_alamat_logo_3": "Footer_footer_alamat_logo_3__FtgwQ",
	"footer_alamat_detail": "Footer_footer_alamat_detail__HCUN1",
	"footer_troffen_label": "Footer_footer_troffen_label___KsZz",
	"footer_bantuan_label": "Footer_footer_bantuan_label__rzLIB",
	"footer_sosial_media_label": "Footer_footer_sosial_media_label__Lwj6L",
	"footer_troffen_detail": "Footer_footer_troffen_detail__7s8z8",
	"footer_bantuan_detail": "Footer_footer_bantuan_detail__oNVFb",
	"footer_sosial_media_detail": "Footer_footer_sosial_media_detail__Zfh0P",
	"tentang_kami": "Footer_tentang_kami__HsNMU",
	"jadi_guru": "Footer_jadi_guru__1o_1S",
	"blog": "Footer_blog__u74mW",
	"FAQ": "Footer_FAQ__VsbVZ",
	"syarat_dan_ketentuan": "Footer_syarat_dan_ketentuan__uKpAa",
	"kebijakan_privasi": "Footer_kebijakan_privasi__CS_Ha",
	"hubungi_kami": "Footer_hubungi_kami__eY0O_",
	"ig": "Footer_ig__GvJX3",
	"fb": "Footer_fb__y94M4",
	"footer_alamat": "Footer_footer_alamat__4u6Z5"
};


/***/ }),

/***/ 7782:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Header_container__434NB",
	"container_navbar": "Header_container_navbar__b_mas",
	"navbar_contents_member": "Header_navbar_contents_member__gCzhk",
	"navbar_contents_login_text": "Header_navbar_contents_login_text__pp6U5",
	"navbar_contents": "Header_navbar_contents__dGxiL",
	"navbar_contents_menu": "Header_navbar_contents_menu__RyIrI",
	"navbar_contents_logo": "Header_navbar_contents_logo__LwB5m",
	"logo1": "Header_logo1__qUOWO",
	"logo1_1": "Header_logo1_1__psMWB",
	"logo1_2": "Header_logo1_2__LpQCI",
	"logo2": "Header_logo2__VrjJe",
	"logo_back": "Header_logo_back__vqfda",
	"navbar_contents_menu1": "Header_navbar_contents_menu1__hr2rs",
	"navbar_contents_menu2": "Header_navbar_contents_menu2__hAPG8",
	"navbar_contents_menu3": "Header_navbar_contents_menu3__YnaW_",
	"navbar_contents_menu4": "Header_navbar_contents_menu4__2bSOv",
	"button_submit": "Header_button_submit__hgmAa",
	"navbar_contents_hamburger": "Header_navbar_contents_hamburger__VosMn",
	"container_responsive_menu": "Header_container_responsive_menu__scaQT",
	"loggedin_menu": "Header_loggedin_menu__Pm9mL",
	"loggedin_menu_body": "Header_loggedin_menu_body__6KTUC",
	"loggedin_username": "Header_loggedin_username__1_NYX",
	"dashboard_label": "Header_dashboard_label__U7Jlv",
	"logout_label": "Header_logout_label__AXae8",
	"dashboard_body": "Header_dashboard_body__u0KWn",
	"logout_body": "Header_logout_body___jGQ5",
	"dashboard_menu": "Header_dashboard_menu__VoVTn",
	"logout_menu": "Header_logout_menu__5KIWr"
};


/***/ }),

/***/ 6874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/001-facebook.25171b58.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEVCa9U9atU8atY8atU9adY9adU8adY8adU9atU8adY8adU9atU8adY8adU9atU8atY8atU8adY9atY8adY9atY9atU8adY8adY8adY8adY8adU9atU9atU9adY9atU9atU9atU9atU8adY8adY9atU8adY9atU8adZHYoqsAAAAJnRSTlMAAAAAAAAAAAEBAQICAgMDAwMEBSUvMDVDSnianaWrrrTO0tXX60RY+FMAAABFSURBVHjaBUAFEoAgENwTWQzE7i78/w8dCKn6ljHoZPr2IIdYPgetoFCb94s4JGZ8r4EZUIbnzJowqbpXqQwCrbtGovAHhUADokzxC0AAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/001-mail.e12a5393.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAUElEQVR42i3HsQ2DQAAEwbG/Cn8bBhGRITJA3wMZXZBB1VyAdpMBik8qwK2ZbGnSIoemgp8WGbD7p50oj6o+VWPk0gHoIqfZYk2LOULxfSs8MlMMAOgQzoEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/002-eye.3a0014ee.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAS0lEQVR42k3MIRJAQABA0YfgChxCFkRGVI1A3OEaXEh0PBvM2Hnlpw85kFbxAZsWQGel8dhNUXAbCWqzy2lROigwqKIemfQt82cEXig8B+dIX4g2AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/002-search.9ef5e3c6.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5UlEQVR42mMAgY++JhofnMwOfXQ2+/8Bgs99cLbQAku+ZbDT+GBt9vmji+l/oKLV711sdr53sT350jtSDqzg+wKZQ58SDP+/F7KyYsAGfu1j+P9rB886EPv05EXcYb3fNgT3fr8Q0vt9f0Dfjx0M/3cx/P+9mx2sYNHyZdyBfd+OAvGtgL7v/wN7f/xnuLNT8XD1Vrv/DJu84VZENP43Cuz59R+o6AADw0Z/DYbN7p+1t7j+V9/ss1Z5m+A6i5Vz/vtNfP85uPO/BliH1xYXDbXNboc0gIo0Nnv8V9kqeVh7YxxYEgDstWyoYmG2oQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_LoginTemplate)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./styles/layout/Header.module.css
var Header_module = __webpack_require__(7782);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
;// CONCATENATED MODULE: ./assets/img/Rectangle63.svg
/* harmony default export */ const Rectangle63 = ({"src":"/_next/static/media/Rectangle63.b1a92a51.svg","height":38,"width":38});
;// CONCATENATED MODULE: ./assets/img/T.svg
/* harmony default export */ const T = ({"src":"/_next/static/media/T.ac4f283b.svg","height":19,"width":20});
;// CONCATENATED MODULE: ./assets/img/Troffen.svg
/* harmony default export */ const Troffen = ({"src":"/_next/static/media/Troffen.1780a08c.svg","height":20,"width":86});
;// CONCATENATED MODULE: ./assets/img/back.svg
/* harmony default export */ const back = ({"src":"/_next/static/media/back.a6c3ce27.svg","height":26,"width":31});
;// CONCATENATED MODULE: ./assets/img/PP.svg
/* harmony default export */ const PP = ({"src":"/_next/static/media/PP.2d15ec27.svg","height":48,"width":48});
;// CONCATENATED MODULE: ./components/layouts/Header.js










function Header({ modalConfig , navbar , handleNavbar  }) {
    const [isClicked, setIsClicked] = (0,external_react_.useState)(false);
    const [isLogin, setIsLogin] = (0,external_react_.useState)(true);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            navbar == "memberNavbar" && /*#__PURE__*/ jsx_runtime_.jsx("section", {
                id: "navbar",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Header_module_default()).container_navbar,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).navbar_contents_member,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Header_module_default()).navbar_contents_logo,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                            className: (Header_module_default()).logo1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    alt: "",
                                                    src: Rectangle63,
                                                    className: (Header_module_default()).logo1_1,
                                                    priority: true
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    alt: "",
                                                    src: T,
                                                    className: (Header_module_default()).logo1_2,
                                                    priority: true
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                            className: (Header_module_default()).logo2,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: Troffen,
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).navbar_contents_menu,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).navbar_contents_button,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                        className: (Header_module_default()).navbar_contents_login_text,
                                        children: [
                                            "Sudah punya akun? ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                onClick: ()=>modalConfig("masuk", true),
                                                children: "Masuk"
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            navbar == "backNavbar" && /*#__PURE__*/ jsx_runtime_.jsx("section", {
                id: "navbar",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Header_module_default()).container_navbar,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).navbar_contents,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Header_module_default()).navbar_contents_logo,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onClick: ()=>handleNavbar(),
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                    className: (Header_module_default()).logo_back,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            alt: "",
                                            src: back,
                                            priority: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                            children: "Kembali"
                                        })
                                    ]
                                })
                            })
                        })
                    })
                })
            }),
            navbar == "" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                id: "navbar",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).container_navbar,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Header_module_default()).navbar_contents,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (Header_module_default()).navbar_contents_logo,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                                className: (Header_module_default()).logo1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        alt: "",
                                                        src: Rectangle63,
                                                        className: (Header_module_default()).logo1_1,
                                                        priority: true
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        alt: "",
                                                        src: T,
                                                        className: (Header_module_default()).logo1_2,
                                                        priority: true
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                className: (Header_module_default()).logo2,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    alt: "",
                                                    src: Troffen,
                                                    priority: true
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (Header_module_default()).navbar_contents_menu,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (Header_module_default()).navbar_contents_menu1,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/cari-guru",
                                                children: "Cari Guru"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (Header_module_default()).navbar_contents_menu2,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/blog",
                                                children: "Blog"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (Header_module_default()).navbar_contents_menu3,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tentang-kami",
                                                children: "Tentang Kami"
                                            })
                                        }),
                                        !isLogin && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (Header_module_default()).navbar_contents_menu4,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        onClick: ()=>modalConfig("daftar", true),
                                                        children: "Daftar"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (Header_module_default()).navbar_contents_button,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: (Header_module_default()).button_submit,
                                                        onClick: ()=>modalConfig("masuk", true),
                                                        children: "Masuk"
                                                    })
                                                })
                                            ]
                                        }),
                                        isLogin && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: (Header_module_default()).loggedin_menu,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: (Header_module_default()).loggedin_username,
                                                            children: "Fauzan Affan"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            alt: "",
                                                            src: PP,
                                                            priority: true
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: (Header_module_default()).loggedin_menu_body,
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    className: (Header_module_default()).dashboard_menu,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: (Header_module_default()).dashboard_label,
                                                                            children: "Content"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: (Header_module_default()).dashboard_body,
                                                                            children: "Dashbor"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    className: (Header_module_default()).logout_menu,
                                                                    onClick: ()=>setIsLogin(false),
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: (Header_module_default()).logout_label,
                                                                            children: "Content"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: (Header_module_default()).logout_body,
                                                                            children: "Logout"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (Header_module_default()).navbar_contents_hamburger,
                                            style: {
                                                backgroundColor: isClicked ? "white" : "transparent"
                                            },
                                            onClick: ()=>setIsClicked(!isClicked),
                                            children: "☰"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    isClicked ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).container_responsive_menu,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/cari-guru",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).responsive_menu1,
                                    children: "Cari Guru"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/blog",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).responsive_menu2,
                                    children: "Blog"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/tentang-kami",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).responsive_menu3,
                                    children: "Tentang Kami"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).responsive_menu4,
                                    onClick: ()=>modalConfig("daftar", true),
                                    children: "Daftar"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Header_module_default()).responsive_menu5,
                                    onClick: ()=>modalConfig("masuk", true),
                                    children: "Masuk"
                                })
                            })
                        ]
                    }) : ""
                ]
            })
        ]
    });
}
/* harmony default export */ const layouts_Header = (Header);

// EXTERNAL MODULE: ./styles/layout/Footer.module.css
var Footer_module = __webpack_require__(1846);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./assets/img/LOGO FOOTER/1.Rectangle63.svg
/* harmony default export */ const _1_Rectangle63 = ({"src":"/_next/static/media/1.Rectangle63.f3a7c819.svg","height":38,"width":38});
;// CONCATENATED MODULE: ./assets/img/LOGO FOOTER/2.T.svg
/* harmony default export */ const _2_T = ({"src":"/_next/static/media/2.T.895e9f19.svg","height":19,"width":20});
;// CONCATENATED MODULE: ./assets/img/LOGO FOOTER/3.Troffen.svg
/* harmony default export */ const _3_Troffen = ({"src":"/_next/static/media/3.Troffen.576fe1e6.svg","height":20,"width":86});
;// CONCATENATED MODULE: ./components/layouts/Footer.js






function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "footer",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Footer_module_default()).footer,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).container,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).footer_menu,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).footer_alamat,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).footer_alamat_logo,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: _1_Rectangle63,
                                                className: (Footer_module_default()).footer_alamat_logo_1
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: _2_T,
                                                className: (Footer_module_default()).footer_alamat_logo_2
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: _3_Troffen,
                                                className: (Footer_module_default()).footer_alamat_logo_3
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).footer_alamat_detail,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                children: "Jln. MH. Thamrin No.8, Kebon Sirih Menteng,"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                children: "Jakarta Pusat"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                children: "(021) 88997765"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                children: "troffen.office@gmail.com"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).footer_troffen,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Footer_module_default()).footer_troffen_label,
                                        children: "Troffen"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).footer_troffen_detail,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).tentang_kami,
                                                children: "Tentang Kami"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).jadi_guru,
                                                children: "Jadi Guru"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).blog,
                                                children: "Blog"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).footer_bantuan,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Footer_module_default()).footer_bantuan_label,
                                        children: "Bantuan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).footer_bantuan_detail,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).FAQ,
                                                children: "FAQ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).syarat_dan_ketentuan,
                                                children: "Syarat & Ketentuan"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).kebijakan_privasi,
                                                children: "Kebijakan Privasi"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).hubungi_kami,
                                                children: "Hubungi Kami"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).footer_sosial_media,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Footer_module_default()).footer_sosial_media_label,
                                        children: "Sosial Media"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).footer_sosial_media_detail,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).ig,
                                                children: "Instagram"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: (Footer_module_default()).fb,
                                                children: "Facebook"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).footer_copyright,
                        children: [
                            "Copyright Troffen",
                            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                                children: new Date().getFullYear()
                            }),
                            "All rights reserved."
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const layouts_Footer = (Footer);

// EXTERNAL MODULE: ./assets/img/png/001-mail.png
var _001_mail = __webpack_require__(7906);
// EXTERNAL MODULE: ./assets/img/png/002-eye.png
var _002_eye = __webpack_require__(9697);
// EXTERNAL MODULE: ./assets/img/png/002-search.png
var _002_search = __webpack_require__(1735);
// EXTERNAL MODULE: ./assets/img/png/001-facebook.png
var _001_facebook = __webpack_require__(6874);
// EXTERNAL MODULE: ./styles/core/Modal.module.css
var Modal_module = __webpack_require__(5414);
var Modal_module_default = /*#__PURE__*/__webpack_require__.n(Modal_module);
;// CONCATENATED MODULE: ./components/core/Modal.js


function Modal({ show , onClose , children , title  }) {
    const handleCloseClick = (e)=>{
        e.preventDefault();
        onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: show && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Modal_module_default()).modal_overlay,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: title === "daftar" ? (Modal_module_default()).modal_daftar : (Modal_module_default()).modal_masuk,
                        children: [
                            title && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Modal_module_default()).modal_title,
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Modal_module_default()).modal_body,
                                children: children
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: title === "daftar" ? (Modal_module_default()).modal_footer_daftar : (Modal_module_default()).modal_footer_masuk,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Modal_module_default()).modal_close,
                            onClick: handleCloseClick,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                children: "x"
                            })
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const core_Modal = (Modal);

;// CONCATENATED MODULE: ./logic/ModalPopupLogic.js









const masukSebagaiLabel = {
    fontWeight: 400
};
const masukSebagaiHr = {
    border: "1px solid"
};
const masukSebagaiSelectedLabel = {
    fontWeight: 600,
    fontSize: "16px"
};
const masukSebagaiSelectedHr = {
    border: "2px solid"
};
function ModalPopupLogic({ onClose , show , title  }) {
    const router = (0,router_.useRouter)();
    const [masukSebagaiType, setMasukSebagaiType] = (0,external_react_.useState)(1);
    const changeLoginType = (type)=>{
        setMasukSebagaiType(type);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_Modal, {
        onClose: ()=>onClose(false),
        show: show,
        title: title,
        children: [
            title === "daftar" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "daftar_modal",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>router.push("/daftar-murid"),
                        className: "button_murid",
                        children: "Daftar Sebagai Murid"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        children: "atau"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>router.push("/daftar-guru"),
                        className: "button_guru",
                        children: "Daftar Sebagai Guru"
                    })
                ]
            }),
            title === "masuk" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "masuk_modal",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "masuk_modal_type",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_sebagai_murid",
                                onClick: ()=>changeLoginType(1),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        style: masukSebagaiType === 1 ? masukSebagaiSelectedLabel : masukSebagaiLabel,
                                        children: "Masuk Sebagai Murid"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        style: masukSebagaiType === 1 ? masukSebagaiSelectedHr : masukSebagaiHr
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_sebagai_guru",
                                onClick: ()=>changeLoginType(2),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        style: masukSebagaiType === 2 ? masukSebagaiSelectedLabel : masukSebagaiLabel,
                                        children: "Masuk Sebagai Guru"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                        style: masukSebagaiType === 2 ? masukSebagaiSelectedHr : masukSebagaiHr
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mobile_masuk_modal_type",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "masuk_sebagai_murid",
                                children: "Masuk Sebagai Murid"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "masuk_sebagai_guru",
                                children: "Masuk Sebagai Guru"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "masuk_modal_body",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_email",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "email",
                                        children: "Email*"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                id: "email",
                                                type: "text",
                                                placeholder: "example@gmail.com"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: _001_mail/* default */.Z,
                                                priority: true,
                                                width: 20,
                                                height: 20
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_password",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "password",
                                        children: "Password*"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                id: "password",
                                                type: "password",
                                                placeholder: "password"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                alt: "",
                                                src: _002_eye/* default */.Z,
                                                priority: true,
                                                width: 20,
                                                height: 20
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_action",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "action_ingat_saya",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "checkbox",
                                                name: "",
                                                id: ""
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                children: "Ingat Saya"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "action_lupa_password",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                            children: "Lupa Password?"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "masuk_submit",
                                children: "Masuk"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "masuk_options",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "masuk_option_label",
                                        children: "atau masuk dengan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "masuk_options_body",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "masuk_google",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        alt: "",
                                                        src: _002_search/* default */.Z,
                                                        priority: true,
                                                        width: 20,
                                                        height: 20
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                        children: "Google"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "masuk_facebook",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        alt: "",
                                                        src: _001_facebook/* default */.Z,
                                                        priority: true,
                                                        width: 20,
                                                        height: 20
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                                        children: "Facebook"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const logic_ModalPopupLogic = (ModalPopupLogic);

;// CONCATENATED MODULE: ./components/layouts/LoginTemplate.js







const LoginTemplate = ({ title , desc , icon , children , isNavbar  })=>{
    const router = (0,router_.useRouter)();
    const [showModal, setShowModal] = (0,external_react_.useState)(false);
    const [menu, setMenu] = (0,external_react_.useState)("");
    const [navbar, setNavbar] = (0,external_react_.useState)("");
    (0,external_react_.useEffect)(()=>{
        isNavbar ? setNavbar(isNavbar) : "";
    }, []);
    const modalConfig = (headerMenu, modalStatus)=>{
        setMenu(headerMenu);
        setShowModal(modalStatus);
    };
    const handleNavbar = ()=>{
        setNavbar("");
        router.back();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: desc
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: `/${icon}`
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Header, {
                modalConfig: modalConfig,
                navbar: navbar,
                handleNavbar: handleNavbar
            }),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(logic_ModalPopupLogic, {
                onClose: setShowModal,
                show: showModal,
                title: menu
            })
        ]
    });
};
/* harmony default export */ const layouts_LoginTemplate = (LoginTemplate);


/***/ })

};
;